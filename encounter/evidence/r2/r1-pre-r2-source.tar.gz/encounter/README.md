# Replay Junction — R1 playable encounter

Illustrated 2.5D early-2000s mall game shop, built on **B-ROWAN-01 / retail-v4** and the selected Kardboard Kings composition direction. R1 is implemented for owner review. Technical qualification, visual assessment, repeatable production and owner acceptance are separate; see [delivery record](../docs/03-production/r1-delivery.md).

## Play

Double-click **Launch Encounter.command** here, or run from any directory:

```sh
'/Users/michaelfuscoletti/Desktop/game-sim/encounter/Launch Encounter.command'
```

Requires the installed Godot 4.6.2 Standard at `/Applications/Godot.app`. The launch opens a fresh practice shift. **Reload** explicitly restores the saved shift. No old prototype or sample save is accessed.

1. Click the receiving box or **Receive 2 copies**. Rowan walks there.
2. Enter a price ($1.00–$99.99), then **Print price labels**.
3. Click the shelf or **Stock both copies**.
4. Click the register or **Open the shop**.
5. Watch the customer browse, select one case and walk to the queue. The shelf loses one available copy at selection; the customer visibly carries it.
6. Click **Complete sale** or the register. Close the shop and inspect the report.
7. **Save**, optionally start a **New practice shift**, then **Reload**.

Clicking an action routes Rowan to its station. Click the floor to walk. **WASD/arrows** also walk and cancel an automatic route; release stops. **E** performs the current guided action by walking to its station. **K** saves; **L** reloads. The price field uses ordinary keyboard editing while focused. Use the visible button after entering the price. New practice shift confirms discarding unsaved progress but leaves the save available.

The two copies are prepaid opening inventory. At $21.99, one sale gives **$571.99 cash, $21.99 revenue, $8.00 cost of goods, $13.99 gross margin, and one remaining copy**. This is gross margin before any overhead. Closing early is allowed: reservations return to the shelf and subsequent sales fail. Purchasing, additional visitors, next-day progression and price-sensitive demand are outside R1.

Save: `~/Library/Application Support/game-sim-r1-review-isolated/encounter.json`. Saves use an atomic temporary-file rename and validate the complete business state before loading. Invalid saves leave the current state intact. Saved customer reservations resume at the corresponding browse/queue checkpoint; exact animation pose and walking position are presentation state and restart coherently on load.

## Evidence and reproduction

- [Gameplay movie](evidence/r1-gameplay.mp4): actual Godot viewport, deterministic actions through the same encounter implementation; not a painted proof fixture or a recording of owner input.
- [Transaction checks](evidence/transaction-checks.json): 20 checks including D1–D3 and persistence.
- [Encounter checks](evidence/encounter-checks.json): 18 checks including viewport mouse events, physical key events, customer routing, layout bounds and reload.
- [Native walkthrough log](evidence/native-playthrough-final.log): real app clicks and keys separately exercised the full sequence and reset/reload at 2× Retina.
- [Retina report](evidence/report-retina.png), [pricing](evidence/pricing-retina.png), [queue](evidence/queued-retina.png), and normal-scale equivalents retain rendered visual evidence.
- [Source manifest](evidence/source-manifest.json), [identity](evidence/identity.json), and [preservation comparison](evidence/preservation-result.json) identify this uncommitted candidate and preserved predecessors.

Use `python3 scripts/validate.py` from this directory for a new disposable project, namespace and timestamped evidence directory. It runs fresh import, state checks and input/route checks, preserving all prior outputs. Pass `--render` for actual normal and Retina captures, or `--capture` for gameplay frames and MP4 as well. These options open temporary Godot windows. Nothing accesses the review save. Capture mode itself uses a unique capture save name.

## Art workflow

Retail-v4 directional cutouts, context and pivots are copied unchanged into `art/`. Their editable masters and production recipe remain in `../samples/b-retail-v4/source/masters/` and `../samples/b-retail-v4/scripts/Rebuild Art.command`. Both standalone samples and the historical game are preserved.

New layered masters: `source/counter.kra`, `case.kra`, `shipment.kra`, and `retail-shelf-empty.kra`. The latter derives from the retained shelf master by hiding its decorative case layer; the two physical cases are separate runtime sprites. Rebuild using `scripts/Rebuild Art.command`; `scripts/build_art.py` is the deterministic native Krita recipe. It saves and reopens every new master, exports PNG, and verifies identical bytes. Run in a disposable copy when retaining prior build logs is important.

PNG: sRGB, straight RGBA, lossless Godot import, linear filtering, mipmaps off, alpha-border correction on; committed-style `.import` sidecars are retained as uncommitted files. Source assets are authored at 4× logical size. Environment props display at .25; case display is .17 on shelf and .085 in hand. Shelf root (640,390), image offset (-125,-115); counter root (785,540), offset (-100,-110); shipment root (310,455), offset (-39,-62). Character feet and limb pivots are in `art/rig.json`, scaled to 110 logical pixels high. `actor.gd` adapts the existing directional rig/pose implementation to separate actors. The old authored-frame comparison remains only in the preserved samples.

Known limits: rigid/deforming legs, abrupt turns/stops, straight-arm reach, possible foot sliding, mirrored lighting and enlarged outline/hidden-surface artifacts. The single customer reuses Rowan's rig with a warm tint and role label; distinct customer identity is deferred. Hands do not animate a detailed cash/register exchange. Shelf/case lettering is decorative; essential price/stock/report text is 18+ logical pixels (world labels 16–17). Krita emits retained Fontconfig/profile/swap/tile warnings; successful reopened exports establish the bounded production result, not warning-free Krita operation.
