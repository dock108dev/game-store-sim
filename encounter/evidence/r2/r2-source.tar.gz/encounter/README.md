# Replay Junction — R2 repeatable business day

R1 was accepted within scope after owner operation: **“ready to build on.”** R2 extends that encounter; R2 owner acceptance is pending. This is not complete-game or release acceptance. See [R2 delivery](../docs/03-production/r2-delivery.md).

## Play

Double-click **Launch Encounter.command**, or run from any directory:

```sh
'/Users/michaelfuscoletti/Desktop/game-sim/encounter/Launch Encounter.command'
```

Godot 4.6.2 Standard is installed at `/Applications/Godot.app`. The launcher starts a fresh day 1. **Reload** explicitly loads an R2 save. The R1 review save is preserved in its separate namespace; R2 does not migrate or overwrite it.

Receive the two prepaid opening copies → enter price → print labels → stock → open → wait for the customer to queue → complete sale → close and review.

At the report, **Order replenishment** opens a preview with editable quantity (1–6 whole copies), unit cost, live total, available cash and arrival day. Invalid or unaffordable quantities disable payment. Confirming pays once. One optional order per day keeps this slice small. **Advance to day …** confirms the transition; receive the pending order at the box on that day, then price/stock/open/sell/close again. Unsold copies keep their existing prices; new labels affect backroom copies only. The desk shows a price range when remaining labels differ. One visitor arrives each day; price-sensitive demand is R3.

Click station/action buttons to route Rowan. Floor clicks and **WASD/arrows** walk; release stops. **E** performs the current guided action. **K** saves, **L** reloads. Text fields use normal editing while focused. **New practice shift** confirms discarding unsaved progress but keeps the save.

## Accounting and persistence

- Revenue: completed sales on the current day, in integer cents.
- Inventory cost: acquisition cost of copies sold that day ($8 each), also called cost of goods sold. Unsold inventory is not expensed in this report.
- Gross profit: revenue minus that sold-copy cost, before overhead. Hover the result text for the in-game definition.
- Cash: $550 opening cash + all completed sales − all paid orders. The original two copies are prepaid; receipt never charges again.
- Remaining stock: all unsold physical copies. Pending shipments are shown separately in the report header and have no inventory copies until receipt.

Example: day 1 sells one copy at $21.99, ending at $571.99 cash and $13.99 gross profit. Ordering two costs $16, leaving $555.99. Day 2 receives two new uniquely identified copies; the unsold original keeps $21.99 even if new copies are labeled $24.99. The next visitor takes the oldest available copy. Selling it ends day 2 at $577.98 cash, $21.99 daily revenue, $8 daily inventory cost, $13.99 daily gross profit and two unsold copies. Cumulative sales revenue is $43.98, cumulative sold-copy cost $16, cumulative gross profit $27.98; the separate $16 purchase payment is not deducted twice.

Save: `~/Library/Application Support/game-sim-r2-review-isolated/encounter.json`. Atomic write/rename and validation preserve business state across ordering, advancement, receipt, pricing, reservation, sale and report. Explicit day tokens guard stale order/advance confirmations. Received markers and physical-copy identities prevent repeat receipt. Daily customers/results reset at advancement; cumulative ledgers persist. Animation poses and walking routes resume from coherent checkpoints, not exact frames.

## Evidence and reproduction

Run from this encounter directory:

```sh
python3 scripts/validate.py --render --capture
```

This makes a disposable project and unique save namespace, imports assets fresh, runs R1 transaction regressions, R2 boundary/invalid-input/cash checks and two-day encounter controls/routes, then normal/Retina captures and actual Godot gameplay recording. Results are retained under timestamped `evidence/validation-*` directories. The movie uses deterministic actions through the same game, not owner input; native control operation is recorded separately. Prior R1 evidence is retained. Exact R2 code/assets, preservation comparison, source archive and final evidence pointers are in `evidence/r2/` and the R2 delivery record.

## Art workflow

Retail-v4 directional cutouts, context and pivots are copied unchanged into `art/`. Their editable masters and production recipe remain in `../samples/b-retail-v4/source/masters/` and `../samples/b-retail-v4/scripts/Rebuild Art.command`. Both standalone samples and the historical game are preserved.

New layered masters: `source/counter.kra`, `case.kra`, `shipment.kra`, and `retail-shelf-empty.kra`. The latter derives from the retained shelf master by hiding its decorative case layer; the physical cases are separate runtime sprites. Rebuild using `scripts/Rebuild Art.command`; `scripts/build_art.py` is the deterministic native Krita recipe. It saves and reopens every new master, exports PNG, and verifies identical bytes. Run in a disposable copy when retaining prior build logs is important.

PNG: sRGB, straight RGBA, lossless Godot import, linear filtering, mipmaps off, alpha-border correction on; committed-style `.import` sidecars are retained as uncommitted files. Source assets are authored at 4× logical size. Environment props display at .25; case display is .17 on shelf and .085 in hand. Shelf root (640,390), image offset (-125,-115); counter root (785,540), offset (-100,-110); shipment root (310,455), offset (-39,-62). Character feet and limb pivots are in `art/rig.json`, scaled to 110 logical pixels high. `actor.gd` adapts the existing directional rig/pose implementation to separate actors. The old authored-frame comparison remains only in the preserved samples.

Known limits: rigid/deforming legs, abrupt turns/stops, straight-arm reach, possible foot sliding, mirrored lighting and enlarged outline/hidden-surface artifacts. The single customer reuses Rowan's rig with a warm tint and role label; distinct customer identity is deferred. Hands do not animate a detailed cash/register exchange. Shelf/case lettering is decorative; essential price/stock/report text is 18+ logical pixels (world labels 16–17). Krita emits retained Fontconfig/profile/swap/tile warnings; successful reopened exports establish the bounded production result, not warning-free Krita operation.
