extends RefCounted
# R1 owns physical copies, never product-level reservations. Money is integer cents.
var data: Dictionary
func _init():
 reset()
func reset():
 data = {"version":2,"day":1,"orders":[],"phase":"prep","received":false,"cash":55000,"items":{},"customers":{},"sales":[],"carried":""}
func receive() -> bool:
 if data.phase != "prep": return false
 if data.received:
  for order in data.orders:
   if not order.received and order.day + 1 == data.day:
    order.received = true
    for n in range(order.quantity):
     data.items["order-%d-copy-%d" % [order.day,n+1]] = {"location":"backroom","owner":"","price":0,"cost":800}
    return true
  return false
 data.received = true
 for id in ["case-01","case-02"]:
  data.items[id] = {"location":"backroom","owner":"","price":0,"cost":800}
 return true
func order(quantity, expected_day: int) -> bool:
 if data.phase != "report" or data.day != expected_day or not quantity is int or quantity < 1 or quantity > 6: return false
 for row in data.orders:
  if row.day == data.day: return false
 if quantity * 800 > data.cash: return false
 data.cash -= quantity * 800
 data.orders.append({"day":data.day,"quantity":quantity,"total":quantity*800,"received":false})
 return true
func advance(expected_day: int) -> bool:
 if data.phase != "report" or data.day != expected_day: return false
 data.day += 1
 data.phase = "prep"
 data.customers.clear()
 data.carried = ""
 return true
func pending_shipment() -> Dictionary:
 for row in data.orders:
  if not row.received: return row
 return {}
func unpriced() -> bool:
 for item in data.items.values():
  if item.location == "backroom" and item.price == 0: return true
 return false
func price(cents: int) -> bool:
 if data.phase != "prep" or not data.received or cents < 100 or cents > 9999: return false
 var changed=false
 for item in data.items.values():
  if item.location == "backroom":
   item.price = cents
   changed=true
 return changed
func stock() -> bool:
 if data.phase != "prep": return false
 var changed = false
 for item in data.items.values():
  if item.location == "backroom" and item.price > 0:
   item.location = "shelf"
   changed = true
 return changed
func open() -> bool:
 if data.phase != "prep" or count_at("shelf") == 0 or count_at("backroom") > 0 or not pending_shipment().is_empty(): return false
 data.phase = "open"
 return true
func reserve(customer: String) -> bool:
 if data.phase != "open" or customer.is_empty() or data.customers.has(customer): return false
 for id in data.items:
  var item = data.items[id]
  if item.location == "shelf" and item.owner == "":
   item.location = "customer"
   item.owner = customer
   data.customers[customer] = {"item":id,"state":"selected"}
   return true
 return false
func queue(customer: String) -> bool:
 if data.phase != "open" or not data.customers.has(customer) or data.customers[customer].state != "selected": return false
 data.customers[customer].state = "queued"
 return true
func sale(customer: String) -> bool:
 if data.phase != "open" or not data.customers.has(customer): return false
 var c = data.customers[customer]
 if c.state != "queued" or not data.items.has(c.item): return false
 var id = c.item
 var item = data.items[id]
 if item.location != "customer" or item.owner != customer: return false
 data.cash += item.price
 data.sales.append({"day":data.day,"item":id,"price":item.price,"cost":item.cost})
 item.location = "sold"
 item.owner = ""
 if data.carried == id: data.carried = ""
 for other in data.customers.values():
  if other.item == id:
   other.item = ""
   other.state = "leaving"
 return true
func close() -> bool:
 if data.phase != "open": return false
 for c in data.customers.values():
  if c.item != "":
   var item = data.items[c.item]
   item.location = "shelf"
   item.owner = ""
  c.item = ""
  c.state = "leaving"
 data.phase = "report"
 return true
func count_at(location: String) -> int:
 var n = 0
 for item in data.items.values():
  if item.location == location: n += 1
 return n
func report() -> Dictionary:
 var revenue = 0
 var cost = 0
 var daily_sold = 0
 for s in data.sales:
  if s.day != data.day: continue
  daily_sold += 1
  revenue += int(s.price)
  cost += int(s.cost)
 return {"revenue":revenue,"cost":cost,"margin":revenue-cost,"cash":data.cash,"sold":daily_sold,"remaining":data.items.size()-data.sales.size()}
func whole(value) -> bool:
 return (value is int or value is float) and is_finite(float(value)) and value == int(value)
func valid() -> bool:
 if data.get("version") != 2 or data.get("phase") not in ["prep","open","report"]: return false
 for key in ["items","customers"]:
  if not data.get(key) is Dictionary: return false
 if not data.get("sales") is Array or not data.get("received") is bool or not data.get("carried") is String: return false
 if not whole(data.get("day")) or data.day < 1 or not data.get("orders") is Array: return false
 var expected = ["case-01","case-02"] if data.received else []
 var purchase_cost = 0
 var order_days = []
 for order_row in data.orders:
  if not order_row is Dictionary: return false
  if not whole(order_row.get("day")) or order_row.day < 1 or order_row.day > data.day or order_days.has(order_row.day): return false
  if not whole(order_row.get("quantity")) or order_row.quantity < 1 or order_row.quantity > 6: return false
  if order_row.get("total") != order_row.quantity * 800 or not order_row.get("received") is bool: return false
  if order_row.received and order_row.day >= data.day: return false
  if not order_row.received and (order_row.day < data.day-1 or (order_row.day == data.day and data.phase != "report") or (order_row.day < data.day and data.phase != "prep")): return false
  order_days.append(order_row.day)
  purchase_cost += int(order_row.total)
  if order_row.received:
   for n in range(int(order_row.quantity)): expected.append("order-%d-copy-%d" % [order_row.day,n+1])
 if data.items.size() != expected.size(): return false
 for id in expected:
  if not data.items.has(id): return false
 if data.phase != "prep" and not data.received: return false
 if data.phase == "prep" and not data.customers.is_empty(): return false
 var sold = []
 var revenue = 0
 for s in data.sales:
  if not s is Dictionary or not data.items.has(s.get("item")) or sold.has(s.item): return false
  if not whole(s.get("day")) or s.day < 1 or s.day > data.day or (s.day == data.day and data.phase == "prep"): return false
  var i = data.items[s.item]
  if not i is Dictionary: return false
  if i.get("location") != "sold" or s.get("price") != i.get("price") or s.get("cost") != 800: return false
  sold.append(s.item)
  revenue += int(s.price)
 if data.get("cash") != 55000 + revenue - purchase_cost or data.cash < 0: return false
 for id in data.items:
  var item = data.items[id]
  if not item is Dictionary or item.get("location") not in ["backroom","shelf","customer","sold"]: return false
  if not item.get("price") is float and not item.get("price") is int: return false
  if item.price != int(item.price) or item.price < 0 or item.price > 9999 or item.get("cost") != 800: return false
  if item.location != "backroom" and item.price < 100: return false
  if data.phase != "prep" and item.location == "backroom": return false
  if item.location == "sold" and not sold.has(id): return false
  if item.location == "customer":
   if data.phase != "open" or not data.customers.has(item.get("owner")): return false
   if data.customers[item.owner].get("item") != id: return false
  elif item.get("owner") != "": return false
  if data.carried == id and item.location != "backroom": return false
 if data.carried != "" and not data.items.has(data.carried): return false
 for id in data.customers:
  var c = data.customers[id]
  if not c is Dictionary or c.get("state") not in ["selected","queued","leaving"]: return false
  if c.state == "leaving":
   if c.get("item") != "": return false
  elif not data.items.has(c.get("item")) or data.items[c.item].owner != id or data.items[c.item].location != "customer": return false
 return true
func save_to(path: String) -> bool:
 if not valid(): return false
 var f = FileAccess.open(path+".tmp",FileAccess.WRITE)
 if f == null: return false
 f.store_string(JSON.stringify(data))
 f.flush()
 var ok = f.get_error() == OK
 f.close()
 return ok and DirAccess.rename_absolute(path+".tmp",path) == OK
func load_from(path: String) -> bool:
 var f = FileAccess.open(path,FileAccess.READ)
 if f == null: return false
 var parsed = JSON.parse_string(f.get_as_text())
 if not parsed is Dictionary: return false
 var candidate = get_script().new()
 candidate.data = parsed
 if not candidate.valid(): return false
 parsed.version = int(parsed.version)
 parsed.cash = int(parsed.cash)
 parsed.day = int(parsed.day)
 for row in parsed.orders:
  row.day = int(row.day);row.quantity = int(row.quantity);row.total = int(row.total)
 for item in parsed.items.values():
  item.price = int(item.price)
  item.cost = int(item.cost)
 for sale_row in parsed.sales:
  sale_row.day = int(sale_row.day)
  sale_row.price = int(sale_row.price)
  sale_row.cost = int(sale_row.cost)
 data = parsed
 return true
