# Game Store Sim — current master plan

Updated 2026-09-08. Illustrated 2.5D early-2000s mall game shop. Kardboard Kings is the composition reference; **B-ROWAN-01 / retail-v4** is the visual baseline. Godot 4.6.2 Standard/GDScript/Compatibility and retained Krita masters remain the workflow.

## Owner decision

After operating R1, the owner said **“ready to build on.”** This is acceptance of the bounded R1 encounter and permission for **R2 — a repeatable business day**. Existing animation limits remain; it is not complete-game or release acceptance. See [R1 record](03-production/r1-delivery.md).

## Current slice

R2 connects finish shift → report → paid replenishment within cash → next day → receive once → price/stock → open/sell → close/report. Existing product, fixtures and one customer per day remain. Daily reports are separate from cumulative sales, orders, cash and physical inventory. R2 is implemented, verified and ready for owner review. A fresh day 1 is the owner handoff. Owner R2 acceptance remains pending.

[Active checklist](03-production/visual-first-task-list.md), [slice plan](03-production/milestones-and-backlog.md), [R2 delivery](03-production/r2-delivery.md), and [launch/controls](../encounter/README.md) govern next work.

## Boundaries

R3 price-sensitive demand, full-shop expansion, large catalogs/casts and broad V2 animation polish remain later work. The inherited rigid/deforming legs, abrupt turns/stops, straight reach, possible sliding, mirrored lighting, enlargement artifacts and reused customer rig remain documented.

Preserve historical game, samples, prior evidence and unrelated uncommitted work. No commit, push or publication. Branch `main`, base `837bd4a8d33ec01fe48dec83bd16fedb9dfaaff1`; the uncommitted candidate is bound by the R2 manifest, not by the base commit alone. Automated qualification, agent visual assessment and owner acceptance are separate.
