# Current slice checklist

Updated 2026-09-08. Baseline: **B-ROWAN-01 / retail-v4**.

- [x] R0 recovery and V1a–V1c direction, motion/art workflow.
- [x] R1 transaction replacement, integrated encounter and technical evidence.
- [x] Owner operated R1: **“ready to build on.”** Bounded R1 accepted; R2 authorized. Not complete-game or release acceptance.
- [x] R2 daily/cumulative state, purchase preview, payment ledger, unique shipment copies and next-day loop.
- [x] Preserve phase, exclusive reservations and sold-reference invariants.
- [x] Disposable transaction and boundary reload checks.
- [x] Complete normal/Retina, two-shift control/routing checks and native operation.
- [x] Retain footage, exact identity, preservation evidence and launch instructions.
- [x] Launch fresh R2 shift for owner operation.
- [ ] Record R2 owner feedback separately; no acceptance inferred from tests.

R3 demand remains later. Full-shop expansion, large catalogs/casts and broad animation polish are deferred. Existing animation limits remain in the R1 record and encounter README. No commit, push or publication.
