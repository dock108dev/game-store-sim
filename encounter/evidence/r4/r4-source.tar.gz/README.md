# Game Store Sim

Current direction: an illustrated 2.5D early-2000s mall game shop, using Kardboard Kings as the primary composition reference and **B-ROWAN-01 / retail-v4** as the current visual baseline. The owner has given strong positive feedback on its appearance. The retail loop remains the product: receive, price, stock, serve, sell, close, review, and decide what comes next.

## Start here

1. [Master plan](docs/MASTER_PLAN.md): current direction and scope.
2. [Slices and backlog](docs/03-production/milestones-and-backlog.md): status, dependencies and completion criteria.
3. [Task checklist](docs/03-production/visual-first-task-list.md): current actionable todos.
4. [Owner feedback](docs/03-production/retail-v4-owner-feedback.md): exact response and its scope.
5. [Retail-v4 sample and launch](samples/b-retail-v4/README.md): retained build report, source assets and evidence. Its pending-review wording is a frozen handoff; the owner-feedback record above is current.
6. [Validation](docs/04-validation/local-validation-plan.md): baseline isolation and evidence rules.

**R1–R3 are accepted within scope.** Owner R3 feedback: **“build on.”** R4 adds a bounded three-customer wave, independent budgets, visible browsing, exclusive reservations, a persisted checkout queue and separate closing/report phases. R4 qualification and owner acceptance are recorded in the [R4 delivery](docs/03-production/r4-delivery.md). [Launch and controls](encounter/README.md). This is not complete-game or release acceptance.

Checkout branch: `main`. R4 started at `837bd4a8d33ec01fe48dec83bd16fedb9dfaaff1`; two externally created local commits appeared during the session, ending at `4b91108fa3cd8d9a2829524c6cf5baed55a236d0`. They were preserved. The agent performed no commit, push or publication; the final candidate includes remaining uncommitted changes and is bound by the R4 manifest.

The old samples and retail-state prototype are preserved separately. The new `encounter/` project integrates the retail-v4 overview with replacement transaction state. Historical documents and retained build reports are evidence, not current work orders. Keep `/Users/michaelfuscoletti/Desktop/game_sim_next_steps.md` synchronized with the master plan.
